package com.norialertapp.utility;

/**
 * Created by katherine_celeste on 10/8/16.
 */
public class Constants {

    public static String MAIL_HOST = "smtp.gmail.com";
    public static String MAIL_SOCKET_PORT = "465";
    public static String MAIL_SOCKET_CLASS = "javax.net.ssl.SSLSocketFactory";
    public static String MAIL_AUTH = "true";
    public static String MAIL_SMTP_PORT = "465";
    public static String MAIL_USERNAME = "parthtestuer@gmail.com";
    public static String MAIL_PASSWORD = "parthtestuser123";

    public static String FROM = "parthtestuer@gmail.com";
    public static String TO = "parthsolanki049@gmail.com";
    public static String CC = "parthsolanki049@gmail.com";
    public static String ROOT_URL = "http://localhost:8080/";
}
